# web-workers-demo
Migrate Long Running JS onto a Web Worker
